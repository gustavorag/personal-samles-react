export default {
  TEMP_C: "c",
  TEMP_F: "f",
  MSG_TYPE_SUCCESS: "SUCCESS",
  MSG_TYPE_ERROR: "ERROR",
  MSG_TYPE_WARNING: "WARNING",
}
